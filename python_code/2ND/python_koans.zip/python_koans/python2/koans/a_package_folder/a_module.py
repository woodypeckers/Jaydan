#!/usr/bin/env python
# -*- coding: utf-8 -*-

class Duck(object):
    @property
    def name(self):
        return "Donald"